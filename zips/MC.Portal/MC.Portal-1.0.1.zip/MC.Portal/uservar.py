import os, xbmc, xbmcaddon

ADDON_ID       = xbmcaddon.Addon().getAddonInfo('id')
ADDONTITLE     = 'MCPortal'
EXCLUDES       = [ADDON_ID, 'repository.merlin']
BUILDFILE      = 'http://'
UPDATECHECK    = 0
APKFILE        = 'https://github.com/MCPortal2017/repository.MCPortal/raw/master/uservar/apks.txt'
YOUTUBETITLE   = 'Videos'
YOUTUBEFILE    = 'https://github.com/MCPortal2017/repository.MCPortal/raw/master/uservar/youtube.txt'
ADDONFILE      = 'https://github.com/MCPortal2017/repository.MCPortal/raw/master/uservar/addons.txt'
ADVANCEDFILE   = 'https://github.com/MCPortal2017/repository.MCPortal/raw/master/uservar/advancedsettings.xml'

PATH           = xbmcaddon.Addon().getAddonInfo('path')
ART            = os.path.join(PATH, 'resources', 'art')

ICONBUILDS     = 'http://'
ICONMAINT      = 'http://'
ICONAPK        = 'http://'
ICONADDONS     = 'http://'
ICONYOUTUBE    = 'http://'
ICONSAVE       = 'http://'
ICONTRAKT      = 'http://'
ICONREAL       = 'http://'
ICONLOGIN      = 'http://'
ICONCONTACT    = 'http://'
ICONSETTINGS   = 'http://'

ICON1          = "special://home/addons/MC.Portal/resources/art/addons.png"
ICON2          = "special://home/addons/MC.Portal/resources/art/apk.png"
ICON3          = "special://home/addons/MC.Portal/resources/art/backup.png"
ICON4          = "special://home/addons/MC.Portal/resources/art/maint.png"
ICON5          = "special://home/addons/MC.Portal/resources/art/configwiz.png"
ICON6          = "special://home/addons/MC.Portal/resources/art/sysinfo.png"
ICON7          = "special://home/addons/MC.Portal/resources/art/swiss.png"
ICON8          = "special://home/addons/MC.Portal/resources/art/youtube.png"
ICON9          = "special://home/addons/MC.Portal/resources/art/info.png"
ICON10         = "special://home/addons/MC.Portal/resources/art/1click.png"

ICONVID1       = "special://home/addons/MC.Portal/resources/art/x.jpg"
ICONVID2       = "special://home/addons/MC.Portal/resources/art/x.jpg"

HIDESPACERS    = 'Yes'
SPACER         = '='

COLOR1         = 'khaki'
COLOR2         = 'teal'
THEME1         = '[COLOR '+COLOR1+'][B][COLOR '+COLOR2+']    [/COLOR][/B][/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
THEME2         = '[COLOR '+COLOR2+']%s[/COLOR]'
THEME3         = '[COLOR '+COLOR1+']%s[/COLOR]'
THEME4         = '[COLOR '+COLOR1+']Current Build:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
THEME5         = '[COLOR '+COLOR1+']Current Theme:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
THEME6         = '[COLOR '+COLOR2+'][B][COLOR '+COLOR1+'][/COLOR][/B][/COLOR] [COLOR '+COLOR1+']%s[/COLOR]'

HIDECONTACT    = 'Yes'
CONTACT        = 'For personal use only and not intended for public domain, if stumbled upon then so be it. I use this to link all the addons that I personally use and they will always come from their official source with their official repo installed!'
CONTACTICON    = 'http://'
CONTACTFANART  = "special://home/addons/MC.Portal/resources/art/aboutfan.jpg"

AUTOUPDATE     = 'Yes'
WIZARDFILE     = ''

AUTOINSTALL    = 'Yes'
REPOID         = 'repository.MCPortal'
REPOADDONXML   = 'https://github.com/MCPortal2017/repository.MCPortal/raw/master/zips/repository.MCPortal/addon.xml'
REPOZIPURL     = 'https://github.com/MCPortal2017/repository.MCPortal/raw/master/zips/repository.MCPortal/'

ENABLE         = 'No'
NOTIFICATION   = ''
HEADERTYPE     = ''
HEADERMESSAGE  = ''
HEADERIMAGE    = ''
BACKGROUND     = ''