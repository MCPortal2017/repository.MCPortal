import os, xbmc, xbmcaddon

ADDON_ID       = xbmcaddon.Addon().getAddonInfo('id')
ADDONTITLE     = 'Merlin Portal'
EXCLUDES       = [ADDON_ID, 'repository.merlin']
BUILDFILE      = 'http://mwiz.co.uk/newmain/builds.txt'
UPDATECHECK    = 0
APKFILE        = 'http://mwiz.co.uk/newmain/apks.txt'
YOUTUBETITLE   = 'Merlin Channel'
YOUTUBEFILE    = 'http://mwiz.co.uk/newmain/youtube.txt'
ADDONFILE      = 'http://mwiz.co.uk/newmain/addons.txt'
ADVANCEDFILE   = 'http://mwiz.co.uk/new/advancedsettings.xml'

PATH           = xbmcaddon.Addon().getAddonInfo('path')
ART            = os.path.join(PATH, 'resources', 'art')

ICONBUILDS     = 'http://'
ICONMAINT      = 'http://'
ICONAPK        = 'http://'
ICONADDONS     = 'http://'
ICONYOUTUBE    = 'http://'
ICONSAVE       = 'http://'
ICONTRAKT      = 'http://'
ICONREAL       = 'http://'
ICONLOGIN      = 'http://'
ICONCONTACT    = 'http://'
ICONSETTINGS   = 'http://'

ICON1        = "special://home/addons/Merlin.Portal/resources/art/addons.png"
ICON2        = "special://home/addons/Merlin.Portal/resources/art/apk.png"
ICON3        = "special://home/addons/Merlin.Portal/resources/art/backup.png"
ICON4        = "special://home/addons/Merlin.Portal/resources/art/maint.png"
ICON5        = "special://home/addons/Merlin.Portal/resources/art/configwiz.png"
ICON6        = "special://home/addons/Merlin.Portal/resources/art/sysinfo.png"
ICON7        = "special://home/addons/Merlin.Portal/resources/art/swiss.png"
ICON8        = "special://home/addons/Merlin.Portal/resources/art/youtube.png"
ICON9        = "special://home/addons/Merlin.Portal/resources/art/info.png"
ICON10        = "special://home/addons/Merlin.Portal/resources/art/1click.png"

ICONVID1        = "special://home/addons/Merlin.Portal/resources/art/jarvis.jpg"
ICONVID2        = "special://home/addons/Merlin.Portal/resources/art/krypton.jpg"


HIDESPACERS    = 'Yes'
SPACER         = '='

COLOR1         = 'khaki'
COLOR2         = 'teal'
THEME1         = '[COLOR '+COLOR1+'][B][COLOR '+COLOR2+']    [/COLOR][/B][/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
THEME2         = '[COLOR '+COLOR2+']%s[/COLOR]'
THEME3         = '[COLOR '+COLOR1+']%s[/COLOR]'
THEME4         = '[COLOR '+COLOR1+']Current Build:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
THEME5         = '[COLOR '+COLOR1+']Current Theme:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
THEME6         = '[COLOR '+COLOR2+'][B][COLOR '+COLOR1+'][/COLOR][/B][/COLOR] [COLOR '+COLOR1+']%s[/COLOR]'

HIDECONTACT    = 'Yes'
CONTACT        = 'Join Us On Facebook (Just Search Merlinites) And Our Own Forum (http://merlin.boards.net)'
CONTACTICON    = 'http://'
CONTACTFANART  = "special://home/addons/Merlin.Portal/resources/art/aboutfan.jpg"

AUTOUPDATE     = 'Yes'
WIZARDFILE     = ''

AUTOINSTALL    = 'Yes'
REPOID         = 'repository.merlin'
REPOADDONXML   = 'http://mrepo.uk/merlinrepo/addons/repository.merlin/addon.xml'
REPOZIPURL     = 'http://mrepo.uk/merlinrepo/addons/repository.merlin/'

ENABLE         = 'No'
NOTIFICATION   = ''
HEADERTYPE     = ''
HEADERMESSAGE  = ''
HEADERIMAGE    = ''
BACKGROUND     = ''
